#!/usr/bin/env python3
import socket
import threading
import redis
from pymongo import MongoClient
from pymongo.errors import PyMongoError
import hiredis
import os
from datetime import datetime
import time
from concurrent.futures import ThreadPoolExecutor

from tier_manager import TierManager
from compression import create_compressor
from promotion import PromotionWorker
from adaptive_partition import AdaptivePartitioner


class TieredCacheProxy:
    
    def __init__(self, proxy_port=6380, redis_host='localhost', redis_port=6379,
                 mongodb_url='mongodb://localhost:27017/ycsb',
                 compression='lz4', promotion_interval=60,
                 hot_memory_percent=5, total_memory_mb=100):
        self.proxy_port = proxy_port
        self.redis_client = redis.Redis(host=redis_host, port=redis_port, decode_responses=False)
        self.mongo_client = MongoClient(mongodb_url)
        self.collection = self.mongo_client.ycsb.usertable
        self.running = False
        
        os.makedirs('result/log', exist_ok=True)
        log_filename = f"result/log/tiered_log_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
        self.log_file = open(log_filename, 'w', encoding='utf-8')
        
        self.tier_manager = TierManager(hot_memory_percent=hot_memory_percent, total_memory_mb=total_memory_mb)
        self.compressor = create_compressor(compression)
        self.adaptive_partitioner = AdaptivePartitioner(self.tier_manager, log_file=self.log_file)
        self.promotion_worker = PromotionWorker(
            self.tier_manager, self.redis_client, self.compressor,
            interval=promotion_interval, log_file=self.log_file,
            adaptive_partitioner=self.adaptive_partitioner
        )
        
        self.executor = ThreadPoolExecutor(max_workers=16, thread_name_prefix='proxy')
        self.size_cache = {}
        
        print(f"Tiered cache proxy initialized:")
        print(f"  - Compression: {compression}")
        print(f"  - Promotion interval: {promotion_interval}s")
        print(f"  - HOT memory limit: {hot_memory_percent}% ({self.tier_manager.HOT_MAX_MEMORY_BYTES / (1024*1024):.2f} MB)")
        print(f"  - COLD memory limit: {100-hot_memory_percent}% ({self.tier_manager.COLD_MAX_MEMORY_BYTES / (1024*1024):.2f} MB)")
        print(f"  - Log: {log_filename}")
    
    def start(self):
        self.running = True
        self.promotion_worker.start()
        
        self.server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.server.bind(('localhost', self.proxy_port))
        self.server.listen(5)
        self.server.settimeout(1.0)  # Set timeout to unblock accept() periodically
        print(f"Tiered proxy started on port {self.proxy_port}")
        
        while self.running:
            try:
                client, addr = self.server.accept()
                self.executor.submit(self.handle_client, client)
            except socket.timeout:
                continue  # Check self.running flag again
            except OSError as e:
                # Expected while shutting down: accept() on a closed socket.
                if self.running:
                    print(f"Server accept error: {e}")
                break
    
    def stop(self):
        print("Stopping tiered cache proxy...")
        self.running = False
        
        # Stop promotion worker first
        self.promotion_worker.stop()
        
        # Close server socket to stop accepting connections
        try:
            if hasattr(self, 'server'):
                self.server.close()
        except OSError as e:
            print(f"Server close error: {e}")
        
        # Shutdown executor with timeout
        if hasattr(self, 'executor'):
            self.executor.shutdown(wait=False)
        
        self._print_final_stats()
        
        if hasattr(self, 'log_file'):
            self.log_file.close()

        if hasattr(self, 'mongo_client'):
            try:
                self.mongo_client.close()
            except Exception as e:
                print(f"Mongo client close error: {e}")
        
        print("Tiered cache proxy stopped")
    
    def handle_client(self, client):
        reader = hiredis.Reader()
        try:
            while self.running:
                data = client.recv(4096)
                if not data:
                    break
                
                reader.feed(data)
                while True:
                    command = reader.gets()
                    if command is False or command is None:
                        break
                    response = self.process_command(command)
                    client.sendall(response)
        except (ConnectionResetError, BrokenPipeError, OSError):
            # Client disconnected abruptly.
            pass
        except Exception as e:
            print(f"Client handler error: {e}")
        finally:
            client.close()
    
    def process_command(self, command):
        if not command or not isinstance(command, list):
            return self.encode_error("ERR empty command")
        
        cmd = command[0].decode('utf-8').upper() if isinstance(command[0], bytes) else command[0].upper()
        
        try:
            if cmd == 'PING':
                return self.encode_simple_string("PONG")
            
            elif cmd == 'HGETALL':
                if len(command) < 2:
                    return self.encode_error("ERR wrong number of arguments")
                
                key = command[1].decode('utf-8')
                return self._handle_read(key)
            
            elif cmd == 'HSET':
                if len(command) < 4:
                    return self.encode_error("ERR wrong number of arguments")
                
                key = command[1].decode('utf-8')
                field = command[2].decode('utf-8')
                value = command[3].decode('utf-8')
                return self._handle_write(key, field, value)
            
            elif cmd == 'DEL':
                if len(command) < 2:
                    return self.encode_error("ERR wrong number of arguments")
                
                keys = [command[i].decode('utf-8') for i in range(1, len(command))]
                return self._handle_delete(keys)
            
            elif cmd == 'EXISTS':
                if len(command) < 2:
                    return self.encode_error("ERR wrong number of arguments")
                
                key = command[1].decode('utf-8')
                result = self._key_exists(key)
                return self.encode_integer(1 if result else 0)
            
            else:
                return self.encode_error(f"ERR unknown command '{cmd}'")
        
        except Exception as e:
            return self.encode_error(f"ERR {str(e)}")
    
    def _estimate_size(self, hash_data, key=None):
        if key and key in self.size_cache:
            return self.size_cache[key]
        
        size = len(hash_data) * 100 + 50
        
        if key:
            self.size_cache[key] = size
        return size
    
    def _check_and_evict_if_needed(self, tier):
        is_over, lru_key = self.tier_manager.check_memory_limit(tier)
        
        if is_over and lru_key:
            if tier == 'hot':
                hot_key = f"data:hot:{lru_key}"
                hash_data = self.redis_client.hgetall(hot_key)
                
                if hash_data:
                    compressed = self.compressor.compress(hash_data)
                    cold_key = f"data:cold:{lru_key}"
                    self.redis_client.set(cold_key, compressed)
                    self.redis_client.delete(hot_key)
                    new_size = len(compressed)
                    self.tier_manager.set_key_size(lru_key, new_size)
                    self.tier_manager.update_tier(lru_key, 'cold')
                    
                    self.log_file.write(f"{lru_key} -> evicted from HOT (memory limit) -> compressed to COLD\n")
                    self.log_file.flush()
            else:
                cold_key = f"data:cold:{lru_key}"
                self.redis_client.delete(cold_key)
                self.tier_manager.remove_key(lru_key)
                
                self.log_file.write(f"{lru_key} -> evicted from COLD (memory limit) -> deleted\n")
                self.log_file.flush()
            return True
        return False
    
    def _handle_read(self, key):
        start_time = time.time()
        
        hot_key = f"data:hot:{key}"
        cold_key = f"data:cold:{key}"
        
        pipe = self.redis_client.pipeline()
        pipe.hgetall(hot_key)
        pipe.get(cold_key)
        value, compressed = pipe.execute()
        
        if value:
            size = self._estimate_size(value, key)
            self.tier_manager.record_access(key, size)
            self.adaptive_partitioner.record_request('hot')
            self.log_file.write(f"{key} -> HOT tier -> cache hit\n")
            self.log_file.flush()
            return self._encode_hash_response(value)
        
        if compressed:
            hash_data = self.compressor.decompress(compressed)
            size = self._estimate_size(hash_data)
            self.tier_manager.record_access(key, size)
            self.adaptive_partitioner.record_request('cold')
            
            # Check if key qualifies for promotion (score-based)
            score = self.tier_manager.calculate_score(key)
            if score >= self.tier_manager.SCORE_THRESHOLD:
                should_promote, target_tier, reason = self.tier_manager.should_promote(key, 'cold')
                
                if should_promote:
                    self._check_and_evict_if_needed('hot')
                    self._promote_immediately(key, hash_data)
                    self.log_file.write(f"{key} -> HOT tier (not found) -> COLD tier -> cache hit -> promotion (real-time)\n")
                else:
                    self.log_file.write(f"{key} -> HOT tier (not found) -> COLD tier -> cache hit (promotion skipped - {reason})\n")
            else:
                self.log_file.write(f"{key} -> HOT tier (not found) -> COLD tier -> cache hit (decompressed)\n")
            
            self.log_file.flush()
            
            result = []
            for k, v in hash_data.items():
                result.append(k.encode('utf-8'))
                result.append(str(v).encode('utf-8'))
            return self.encode_array(result)
        
        doc = self.collection.find_one({'_id': key})
        if doc:
            hash_data = {}
            for k, v in doc.items():
                if k == '_id':
                    continue
                hash_data[k] = v.decode('utf-8') if isinstance(v, bytes) else str(v)
            
            size = self._estimate_size(hash_data)
            self._check_and_evict_if_needed('cold')
            
            compressed = self.compressor.compress(hash_data)
            self.redis_client.set(cold_key, compressed)
            
            compressed_size = len(compressed)
            self.tier_manager.record_access(key, compressed_size)
            self.tier_manager.update_tier(key, 'cold')
            self.adaptive_partitioner.record_request('miss')
            
            self.log_file.write(f"{key} -> cache miss -> MongoDB -> found -> update redis (COLD tier, compressed)\n")
            self.log_file.flush()
            
            result = []
            for k, v in hash_data.items():
                result.append(k.encode('utf-8'))
                result.append(str(v).encode('utf-8'))
            return self.encode_array(result)
        
        return self.encode_array([])
    
    def _promote_immediately(self, key, hash_data):
        try:
            size = self._estimate_size(hash_data)
            
            pipe = self.redis_client.pipeline()
            for field, value in hash_data.items():
                pipe.hset(f"data:hot:{key}", field, str(value))
            pipe.delete(f"data:cold:{key}")
            pipe.execute()
            
            self.tier_manager.key_stats[key]['size'] = size
            self.tier_manager.update_tier(key, 'hot')
        except Exception as e:
            print(f"Immediate promotion error for {key}: {e}")
    
    def _handle_write(self, key, field, value):
        # Source of truth first: if Mongo write fails, do not mutate cache.
        try:
            self.collection.update_one({'_id': key}, {'$set': {field: value}}, upsert=True)
        except PyMongoError as e:
            return self.encode_error(f"ERR mongodb write failed: {str(e)}")

        current_tier = self.tier_manager.get_tier(key)
        tier_key = f"data:{current_tier}:{key}"
        hash_data = None
        
        if current_tier == 'cold':
            compressed = self.redis_client.get(tier_key)
            if compressed:
                hash_data = self.compressor.decompress(compressed)
                hash_data[field] = value
                compressed = self.compressor.compress(hash_data)
                self.redis_client.set(tier_key, compressed)
                size = len(compressed)
            else:
                hash_data = {field: value}
                compressed = self.compressor.compress(hash_data)
                self.redis_client.set(tier_key, compressed)
                size = len(compressed)
        else:
            result = self.redis_client.hset(tier_key, field, value)
            hash_data = self.redis_client.hgetall(tier_key)
            size = self._estimate_size(hash_data)
        
        self.tier_manager.record_access(key, size)
        self._check_and_evict_if_needed(current_tier)
        return self.encode_integer(1)
    
    def _handle_delete(self, keys):
        count = 0
        for key in keys:
            pipe = self.redis_client.pipeline()
            pipe.delete(f"data:hot:{key}")
            pipe.delete(f"data:cold:{key}")
            results = pipe.execute()
            
            if any(results):
                count += 1
                self.tier_manager.remove_key(key)
        return self.encode_integer(count)
    
    def _key_exists(self, key):
        return (self.redis_client.exists(f"data:hot:{key}") or
                self.redis_client.exists(f"data:cold:{key}"))
    
    def _encode_hash_response(self, hash_data):
        result = []
        for k, v in hash_data.items():
            result.append(k)
            result.append(v)
        return self.encode_array(result)
    
    def _print_final_stats(self):
        pass
    
    def encode_simple_string(self, s):
        return f"+{s}\r\n".encode('utf-8')
    
    def encode_error(self, err):
        return f"-{err}\r\n".encode('utf-8')
    
    def encode_integer(self, i):
        return f":{i}\r\n".encode('utf-8')
    
    def encode_bulk_string(self, s):
        if s is None:
            return b"$-1\r\n"
        if isinstance(s, str):
            s = s.encode('utf-8')
        return f"${len(s)}\r\n".encode('utf-8') + s + b"\r\n"
    
    def encode_array(self, arr):
        if not arr:
            return b"*0\r\n"
        result = f"*{len(arr)}\r\n".encode('utf-8')
        for item in arr:
            result += self.encode_bulk_string(item)
        return result


if __name__ == '__main__':
    proxy = TieredCacheProxy(
        proxy_port=6380,
        compression='lz4',
        promotion_interval=30
    )
    try:
        proxy.start()
    except KeyboardInterrupt:
        proxy.stop()
